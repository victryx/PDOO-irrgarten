package irrgarten;

/**
 * Tipos de desplazamiento
 * @author vik
 */
public enum Orientation {
    VERTICAL,
    HORIZONTAL
}