package irrgarten;

/**
 Tipos de personajes del juego (jugador o monstruo)
 * @author vik
 */
public enum GameCharacter {
    PLAYER,
    MONSTER
    
}