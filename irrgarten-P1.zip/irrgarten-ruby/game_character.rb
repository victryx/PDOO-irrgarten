# frozen_string_literal: true
# encoding: utf-8

module Irrgarten

  module GameCharacter
    PLAYER = :player
    MONSTER = :monster
  end

end
